import React from 'react';
import './VerticalAdCard.scss';

function VerticalAdCard() {
  return (
    <div className="vertical-ad-card">
      <p>Add here...</p>
    </div>
  );
}

export default VerticalAdCard;
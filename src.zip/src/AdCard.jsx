import React from 'react';
import './AdCard.scss';

function AdCard() {
  return (
    <div className="ad-card">
      <p>Add here</p>
    </div>
  );
}

export default AdCard;

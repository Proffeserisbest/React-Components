import React from 'react';


function AdCard() {
  return (
    <div>
      <AdCard />
    </div>
  );
}

export default AdCard;
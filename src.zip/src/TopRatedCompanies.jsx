import React from "react";
import "./TopRatedCampines.scss";

const TopRatedCampines = () => {

  return (
    <div className="top-rated-campines">
      <h2>Top Rated Campines</h2>
      <div className="header-divider"></div>
      
    </div>
  );
}

export default TopRatedCampines;